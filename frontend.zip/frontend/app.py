import streamlit as st
import requests
import pandas as pd

BACKEND = "http://localhost:8000"  # Adjust if deployed elsewhere

def get_dynamic_height(num_rows, row_height=35, max_height=600):
    return min(num_rows * row_height, max_height)

st.set_page_config(page_title="LegalEase AI", layout="wide")
st.title("📜 LegalEase AI – Document Analysis Platform")

# Upload document
st.header("Upload a Legal Document")
uploaded = st.file_uploader("Select a PDF, DOCX, or TXT document to upload", type=["pdf", "docx", "txt"])

if uploaded:
    with st.spinner("Uploading and processing document..."):
        response = requests.post(f"{BACKEND}/upload", files={"file": uploaded})
    if response.status_code == 200:
        data = response.json()
        if "error" in data:
            st.error(f"Backend error: {data['error']}")
        else:
            st.success("Document processed successfully!")
            st.subheader("Summary")
            st.write(data.get("summary", ""))

            orig_paragraphs = data.get("original_paragraphs", [])
            simplified_paragraphs = data.get("simplified_paragraphs", [])

            st.subheader("Paragraph-wise Comparison")
            if orig_paragraphs and simplified_paragraphs and len(orig_paragraphs) == len(simplified_paragraphs):
                num_paragraphs = len(orig_paragraphs)
                height = get_dynamic_height(num_paragraphs)

                col1, col2 = st.columns(2)
                with col1:
                    st.write("Original")
                    df_orig = pd.DataFrame({"Paragraph": orig_paragraphs})
                    st.dataframe(df_orig, height=height, use_container_width=True)
                with col2:
                    st.write("Simplified")
                    df_simp = pd.DataFrame({"Paragraph": simplified_paragraphs})
                    st.dataframe(df_simp, height=height, use_container_width=True)
            else:
                st.warning("Paragraph comparison data incomplete.")

            st.subheader("Ask Questions About the Document")
            question = st.text_input("Enter your question")

            if st.button("Get Answer") and question:
                with st.spinner("Getting answer..."):
                    r = requests.post(f"{BACKEND}/qa", json={"question": question})
                if r.status_code == 200:
                    answer = r.json().get("answer", "No answer found.")
                    st.write(answer)
                else:
                    st.error("Error getting answer from backend.")
    else:
        st.error(f"Upload failed: {response.text}")
else:
    st.info("Please upload a legal document to get started.")
